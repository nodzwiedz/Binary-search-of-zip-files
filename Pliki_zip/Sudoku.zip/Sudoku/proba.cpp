/// POP 2017-12-21 projekt 1 Niedźwiecki Błażej AIR 2 172151 CODE-BLOCKS 13.11 compilator - MinGW 32 domyslne srodowisko
#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <cstdlib>
#include <ctime>
#include <math.h>


using namespace std;

    struct historia{
        string position;
        int number;
        int previous_number;
    };

    struct miejsce{
    int x;
    int y;
    };


    void instrukcja(){
        cout <<"----------------------------------------------------INSTRUKCJA----------------------------------------------------" << endl << endl;
        cout <<"Kwadratowa plansza jest podzielona na dziewiec identycznych kwadratów 3 x 3"<<endl
             <<"w kazdym z nich znajduje sie dziewiec komorek." << endl
             <<"Twoim zadaniem jest wypelnienie wszystkich komórek planszy cyframi od 1 do 9." <<endl
             <<"W kazdym wierszu, kolumnie oraz malym kwadracie 3x3 dana cyfra moze wystepowac jedynie raz." << endl
             <<"Jezeli chcemy wpisac lub zmienic cyfre, nalezy podac najpierw KOLUMNE a nastepnie WIERSZ, np. A4, D1 itd." << endl
             <<"Przy wpisaniu 0 uzytkownik usuwa dana cyfre na podanym miejscu" << endl
             <<"NIE MOZNA ZMIENIAC CYFR PODANYCH NA STARCIE GRY!!!" << endl
             <<"Cyfry wstawione na poczatku gry sa zapisane pomiedzy pionowymi kreskami | |" << endl << endl
             <<"DOZWOLONE RUCHY:" << endl
             <<"Pozycja : ([A-I][1-9])" << endl
             <<"Kasowanie : 0" << endl
             <<"Tylko JEDNA PODPOWIEDZ na runde!" << endl
             <<"------------------------------------------------------------------------------------------------------------------" << endl;

    }


    void wyswietlanie(int gra[][9],int kopia_gra[][9]){                                               ///wyswietlanie tablicy
        cout << "    A  B  C   D  E  F   G  H  I" << endl;
        cout << "  ###############################" << endl;
        for(int i=1;i<=9;i++){
            cout << i << " #";
            for(int j=1;j<=9;j++){
                if(gra[i-1][j-1]==0) cout << "   ";
                else if(kopia_gra[i-1][j-1]==0) cout << " " << gra[i-1][j-1] << " ";
                else cout << "|" << gra[i-1][j-1] << "|";

                if(j%3==0) cout << "#";
            }
            cout << endl;
            if(i!=9 && i%3!=0) cout << "  #---------#---------#---------#" << endl;
            if(i%3==0 && i!=9) cout << "  ###############################" << endl;
        }
        cout << "  ###############################";
    }


    void wstawianie(int gra[][9], int kopia_gra[][9], string pozycja, int cyfra, int &puste, historia H[]){

        int kolumna=pozycja[0]-64;                      ///ASCII
        int wiersz=pozycja[1]-48;


        if(kopia_gra[wiersz-1][kolumna-1]==0){          ///jesli nie oryginalne miejsce, to ok, wpisz

                if(cyfra==0) puste++;
                else puste--;

                for(int i=18;i>=0;i--) H[i+1]=H[i];     ///wstawiam ruch do historii
                H[0].position=pozycja;
                H[0].number=cyfra;
                H[0].previous_number=gra[wiersz-1][kolumna-1];

                gra[wiersz-1][kolumna-1]=cyfra;

        }
        else{
            cout << "NIEDOZWOLONY RUCH. TEGO MIEJSCA NIE MOZNA ZMIENIAC" << endl << endl;
        }
    }

    void cofanie(historia H[],int gra[][9],int ile,int &puste){
        int kolumna,wiersz;

        for(int i=0;i<ile;i++){
            kolumna=H[0].position[0]-64;
            wiersz=H[0].position[1]-48;
            gra[wiersz-1][kolumna-1]=H[0].previous_number;                              ///wstawiam do gry cyfre ktora byla wczesniej
            if(H[0].previous_number==0) puste++;
            for(int i=0;i<19;i++) H[i]=H[i+1];                                          ///usuwam z historii pierwszy element
        }

    }

    void pomoc(int gra[][9],int rozwiazanie[][9],int &puste, historia H[]){

        miejsce Lokalizacja[puste];                                                     ///tablica lokalizacji pustych miejsc
        int pozycja_w_Lokalizacji=0;

        for(int i=0;i<9;i++){
            for(int j=0;j<9;j++){
                if(gra[i][j]==0){
                    Lokalizacja[pozycja_w_Lokalizacji].x=i;                             ///wsadzam x i y do tablicy zeby potem wylosowac jakis punkt
                    Lokalizacja[pozycja_w_Lokalizacji].y=j;
                    pozycja_w_Lokalizacji++;
                }
            }
        }

        pozycja_w_Lokalizacji=rand()%puste;

        int x=Lokalizacja[pozycja_w_Lokalizacji].x;
        int y=Lokalizacja[pozycja_w_Lokalizacji].y;

        for(int i=18;i>=0;i--) H[i+1]=H[i];                                             ///wstawiam ruch do historii
        string pozycja;
        char duza = y+65;
        char cyfra=x+49;
        pozycja+=duza;
        pozycja+=cyfra;
        H[0].position=pozycja;
        H[0].number=rozwiazanie[x][y];
        H[0].previous_number=gra[x][y];

        gra[x][y]=rozwiazanie[x][y];                                                    ///do sudoku wstawiam ten losowy, poprawny punkt

        puste--;

        char odAdoI=y+65;
        cout << endl << "Wszyskie dotychczasowe rozwiazania sa poprawne dlatego wstawilem odpowiedz na miejsce " << odAdoI << x+1 << endl << endl;
    }

int main() {
    setlocale(LC_ALL,"");
    srand(time (0));

    instrukcja();
    cout << endl << endl;

    int poziom;

    while( true ) {
        cout << "Wybierz poziom trudnosci gry (1-5):" << endl
             << "1. Bardzo latwy" << endl
             << "2. Latwy" << endl
             << "3. Sredni" << endl
             << "4. Trudny" << endl
             << "5. Killer" << endl;

        cin >> poziom;

        if(poziom<=5 && poziom>=1) break;
        else cout << "PODAJ CYFRE Z ZAKRESU 1-5" << endl;
    }

    int gra[9][9];
    int kopia_gra[9][9];
    int rozwiazanie[9][9];
    historia H[20];

    for(int i=0;i<20;i++){
        H[i].number=11;
        H[i].previous_number=11;
        H[i].position="";
    }

    int liczba;
    string nazwa_pliku;

    switch(poziom){
        case 1: nazwa_pliku="sudoku1.txt"; break;
        case 2: nazwa_pliku="sudoku2.txt"; break;
        case 3: nazwa_pliku="sudoku3.txt"; break;
        case 4: nazwa_pliku="sudoku4.txt"; break;
        case 5: nazwa_pliku="sudoku5.txt"; break;
    }

    int puste_miejsca=0;

    ifstream plik;                                      ///zczytuje dane z pliku i wpisuje je do tablicy z gra
    plik.open(nazwa_pliku.c_str());
        for(int i=0; i<9;i++){
            for(int j=0;j<9;j++){
                plik >> liczba;
                gra[i][j]=liczba;
                kopia_gra[i][j]=liczba;                       ///robie tez kopie
                if(liczba==0) puste_miejsca++;
            }
        }

        for(int i=0; i<9;i++){                          ///rozwiazanie zapisuje w tablicy
            for(int j=0;j<9;j++){
                plik >> liczba;
                rozwiazanie[i][j]=liczba;
            }
        }

    plik.close();

    string pozycja;
    int cyfra;
    char YESorNOT;

    while(puste_miejsca>0){

        wyswietlanie(gra,kopia_gra);

        cout << endl << endl << "Czy chcesz jakas pomoc?(T/N)";
        cin >> YESorNOT;
        bool znalazl_blad=false;
        char duza_litera;

        if(YESorNOT=='T' || YESorNOT=='t'){
                for(int i=0;i<9;i++){
                    for(int j=0;j<9;j++){
                        if(gra[i][j]!=0 && gra[i][j]!=rozwiazanie[i][j]){
                            znalazl_blad=true;
                            duza_litera=j+65;
                            cout << "Masz blad na pozycji " << duza_litera << i+1 << ". Usunalem go."<< endl;
                            gra[i][j]=0;
                        }
                    }
                }

                if(znalazl_blad==false){
                pomoc(gra,rozwiazanie,puste_miejsca,H);
                wyswietlanie(gra,kopia_gra);
                cout << endl;
                }
                else{
                    cout << endl;
                    wyswietlanie(gra,kopia_gra);
                    cout << endl;
                }
        }

        cout << "Podaj pozycje: ";
        cin >> pozycja;
        cout << "Podaj cyfre: ";
        cin >> cyfra;

        int litera=pozycja[0];

        if(litera>=65 && litera<=73 && cyfra>=0 && cyfra<=9){
            wstawianie(gra,kopia_gra,pozycja,cyfra,puste_miejsca,H);
        }
        else{
            cout << "Podales zle parametry!!!" << endl;
            continue;
        }


        cout << "Czy wyswietlic historie ruchow? (T/N)";
        cin >> YESorNOT;

        if(YESorNOT=='T' || YESorNOT=='t'){                                                      ///wyswietlanie historii
            cout << "HISTORIA RUCHOW:" << endl;
            for(int i=0;i<20;i++){
                if(H[i].number==11) break;
                cout << i+1 << ". " << H[i].position << " -> ";
                if(H[i].number==0) cout << "- zamiast ";
                else cout << H[i].number << " zamiast ";

                if(H[i].previous_number==0) cout << "-" << endl;
                else cout << H[i].previous_number << endl;
            }
            cout << endl;
            cout << "Czy chcesz cofnac ruch? (T/N)";                                        ///cofanie ruchow
            cin >> YESorNOT;
            cout << endl;
            if(YESorNOT=='T' || YESorNOT=='t'){
                cout << "Ile ruchow chcesz cofnac?";
                cin >>cyfra;
                if(cyfra>20) break;
                cofanie(H,gra,cyfra,puste_miejsca);
            }
        }


        int bledy=0;

        if(puste_miejsca==0){
            for(int i=0;i<9;i++){
                for(int j=0;j<9;j++){
                    if(gra[i][j]!=rozwiazanie[i][j]){
                        gra[i][j]=0;                                                    ///jesli jest gdzies blad to czyszcze to miejsce
                        bledy++;
                    }
                }
            }
            if(bledy==0) cout << endl << "GRATULACJE, POPRAWNIE ROZWIAZALES SUDOKU!!!" << endl;
            else{
                cout << endl << "Masz " << bledy << " bledow! POPRAW JE!" << endl;
                puste_miejsca=bledy;
            }
        }

    }



return 0;
}
