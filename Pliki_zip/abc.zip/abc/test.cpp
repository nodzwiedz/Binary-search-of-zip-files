#include<iostream>
#include<fstream>
#include<string>
#include<string.h>
#include<conio.h>
#include<cstdlib>
#include<ctime>
#include<math.h>
#include<cstdio>


using namespace std;



int main() {
setlocale(LC_ALL,"");
srand(time (0));

ifstream plik;
string nazwa_pliku;
nazwa_pliku="abc.zip";
plik.open(nazwa_pliku.c_str(), ios::in | ios::binary );
    int cztery=0;
    plik.read((char*)&cztery,4);
    cout <<"pierwsze cztery: " << cztery << endl;
    int wersja=0;
    plik.read((char*)&wersja,2);
    cout <<"Wersja: "<< wersja << endl;
    int flagi=0;
    plik.read((char*)&flagi,2);
    cout <<"Flagi: "<< flagi << endl;
    int metoda=0;
    plik.read((char*)&metoda,2);
    cout <<"Metoda: "<< metoda << endl;
    int czas=0;
    plik.read((char*)&czas,2);
    cout <<"Czas: "<< czas << endl;
    int data=0;
    plik.read((char*)&data,2);
    cout <<"Data: "<< data << endl;
    int crc32=0;
    plik.read((char*)&crc32,4);
    cout <<"crc32: "<< crc32 << endl;
    int rozmiar_skompresowanego=0;
    plik.read((char*)&rozmiar_skompresowanego,4);
    cout <<"rozmiar_skompresowanego: "<< rozmiar_skompresowanego << endl;
    int rozmiar_rozpakowanego=0;
    plik.read((char*)&rozmiar_rozpakowanego,4);
    cout <<"rozmiar_rozpakowanego: "<< rozmiar_rozpakowanego << endl;
    int dlugosc_nazwy=0;
    plik.read((char*)&dlugosc_nazwy,2);
    cout <<"dlugosc_nazwy: "<< dlugosc_nazwy<< endl;
    int dodatkowa_dlugosc_nazwy=0;
    plik.read((char*)&dodatkowa_dlugosc_nazwy,2);
    cout <<"dodatkowa_dlugosc_nazwy: "<< dodatkowa_dlugosc_nazwy<< endl;


plik.close();

return 0;
}
